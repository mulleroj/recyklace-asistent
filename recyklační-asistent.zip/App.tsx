
import React, { useState, useRef, useEffect, useMemo } from 'react';
import { identifyWaste } from './services/geminiService';
import { WasteItem, ChatHistoryItem, WasteCategory } from './types';
import CategoryBadge, { getCategoryIcon, getCategoryStyles } from './components/CategoryBadge';
import { WASTE_DATABASE } from './constants';
import { findLocalMatch } from './utils/fuzzySearch';

const STORAGE_KEY = 'recyklacni_asistent_history';

// Rozšíření typů pro Web Speech API
interface SpeechRecognitionEvent extends Event {
  results: SpeechRecognitionResultList;
}
interface SpeechRecognition extends EventTarget {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  start: () => void;
  stop: () => void;
  onstart: () => void;
  onresult: (event: SpeechRecognitionEvent) => void;
  onerror: (event: any) => void;
  onend: () => void;
}
declare var webkitSpeechRecognition: {
  new (): SpeechRecognition;
};

const App: React.FC = () => {
  const [query, setQuery] = useState('');
  const [result, setResult] = useState<(WasteItem & { source?: 'local' | 'ai' }) | null>(null);
  const [loading, setLoading] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [isListening, setIsListening] = useState(false);
  
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const [history, setHistory] = useState<ChatHistoryItem[]>(() => {
    try {
      const savedHistory = localStorage.getItem(STORAGE_KEY);
      return savedHistory ? JSON.parse(savedHistory) : [];
    } catch (e) {
      console.error("Failed to load history from localStorage", e);
      return [];
    }
  });

  const [error, setError] = useState<string | null>(null);
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(history));
  }, [history]);

  // Hlasové vyhledávání (STT) logic
  const startSpeechRecognition = () => {
    if (!('webkitSpeechRecognition' in window)) {
      setError('Hlasové vyhledávání není ve vašem prohlížeči podporováno.');
      return;
    }

    const recognition = new webkitSpeechRecognition();
    recognition.lang = 'cs-CZ';
    recognition.continuous = false;
    recognition.interimResults = false;

    recognition.onstart = () => {
      setIsListening(true);
      setError(null);
    };

    recognition.onresult = (event: SpeechRecognitionEvent) => {
      const transcript = event.results[0][0].transcript;
      setQuery(transcript);
      handleIdentify({ text: transcript });
    };

    recognition.onerror = (event: any) => {
      if (event.error === 'no-speech') {
        setError('Nebylo slyšet žádné slovo.');
      } else {
        setError('Chyba mikrofonu.');
      }
      setIsListening(false);
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    recognition.start();
  };

  /**
   * Funkce pro hlasové oznámení kategorie (TTS)
   * Extrahuje barvu z WasteCategory a přečte ji
   */
  const announceResult = (category: string) => {
    if (!soundEnabled) return;

    // 1. Zvukový signál (Earcon)
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const playNote = (freq: number, startTime: number, duration: number) => {
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.frequency.setValueAtTime(freq, startTime);
        gain.gain.setValueAtTime(0, startTime);
        gain.gain.linearRampToValueAtTime(0.1, startTime + 0.05);
        gain.gain.exponentialRampToValueAtTime(0.001, startTime + duration);
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start(startTime);
        osc.stop(startTime + duration);
      };
      playNote(523.25, audioCtx.currentTime, 0.2); // Krátký tón C5
      setTimeout(() => audioCtx.close(), 1000);
    } catch (e) { console.warn("Audio Context error:", e); }

    // 2. Hlasové oznámení barvy
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel(); // Zastavit případné předchozí mluvení

      // Získáme barvu z řetězce (např. "Žlutá" z "Žlutá: Plasty")
      const colorToSpeak = category.includes(':') 
        ? category.split(':')[0].trim() 
        : category;

      const utterance = new SpeechSynthesisUtterance(colorToSpeak);
      utterance.lang = 'cs-CZ';
      utterance.rate = 1.0;
      utterance.pitch = 1.0;
      window.speechSynthesis.speak(utterance);
    }
  };

  const startCamera = async () => {
    if (!isOnline) {
      setError('Focení vyžaduje připojení k internetu pro AI analýzu.');
      return;
    } 
    try {
      setError(null);
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'environment' },
        audio: false 
      });
      setCameraStream(stream);
      setIsCameraOpen(true);
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err) {
      setError('Nepodařilo se zapnout kameru.');
    }
  };

  const stopCamera = () => {
    if (cameraStream) {
      cameraStream.getTracks().forEach(track => track.stop());
      setCameraStream(null);
    }
    setIsCameraOpen(false);
  };

  const capturePhoto = async () => {
    if (!videoRef.current || !canvasRef.current) return;
    const canvas = canvasRef.current;
    const video = videoRef.current;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const base64Data = canvas.toDataURL('image/jpeg', 0.8).split(',')[1];
    stopCamera();
    handleIdentify({ image: { data: base64Data, mimeType: 'image/jpeg' } });
  };

  const handleIdentify = async ({ text, image }: { text?: string, image?: { data: string, mimeType: string } }) => {
    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const timestamp = Date.now();
      
      // 1. Lokální databáze
      if (text) {
        const localMatch = findLocalMatch(text, WASTE_DATABASE);
        if (localMatch) {
          const res: WasteItem & { source?: 'local' | 'ai' } = {
            id: 'local-' + Math.random().toString(36).substring(7),
            ...localMatch,
            isFromDatabase: true,
            source: 'local'
          };
          setResult(res);
          announceResult(res.category);
          setHistory(prev => [{ query: text, result: res, timestamp }, ...prev.slice(0, 49)]);
          setQuery('');
          setLoading(false);
          return;
        }
      }

      // 2. AI analýza (vyžaduje online)
      if (!isOnline) {
        setError(image ? 'Focení vyžaduje internet.' : 'Tuto položku nemám v databázi a jste offline.');
        setLoading(false);
        return;
      }

      const aiRes = await identifyWaste({ query: text, image });
      const resWithSource: WasteItem & { source?: 'local' | 'ai' } = { ...aiRes, source: 'ai' };
      setResult(resWithSource);
      announceResult(resWithSource.category);
      setHistory(prev => [{ query: text || aiRes.name, result: resWithSource, timestamp }, ...prev.slice(0, 49)]);
      if (text) setQuery('');
    } catch (err) {
      setError('Nepodařilo se spojit s asistentem.');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!query.trim()) return;
    handleIdentify({ text: query.trim() });
  };

  return (
    <div className={`min-h-screen transition-all duration-1000 ${isOnline ? 'bg-emerald-50' : 'bg-slate-200'} text-slate-900 pb-20`}>
      
      {!isOnline && (
        <div className="bg-orange-600 text-white py-3 px-4 text-center font-bold text-lg sticky top-0 z-50 shadow-lg">
           Režim offline: Pouze lokální databáze 📦
        </div>
      )}

      <header className={`transition-all duration-700 border-b-[10px] shadow-xl sticky ${!isOnline ? 'top-[48px]' : 'top-0'} z-30 ${isOnline ? 'bg-emerald-600 border-emerald-800' : 'bg-slate-700 border-slate-900'}`}>
        <div className="max-w-2xl mx-auto px-4 h-24 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="bg-white p-2 rounded-2xl">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-emerald-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
              </svg>
            </div>
            <h1 className="text-white text-2xl font-black uppercase italic">Třídič</h1>
          </div>
          <button 
            onClick={() => setSoundEnabled(!soundEnabled)}
            className={`p-4 rounded-2xl border-2 transition-all active:scale-90 flex items-center gap-2 ${soundEnabled ? 'bg-white/20 text-white border-white/30' : 'bg-black/20 text-white/40 border-black/10'}`}
          >
            <span className="text-xl">{soundEnabled ? '🔊' : '🔇'}</span>
            <span className="text-xs font-bold uppercase hidden sm:inline">{soundEnabled ? 'Hlas zap' : 'Ticho'}</span>
          </button>
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-4 pt-10">
        
        <section className="mb-10">
          <form onSubmit={handleSubmit} className="relative mb-6">
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Napište název odpadu..."
              className="w-full h-24 px-8 pr-20 rounded-[35px] border-[8px] border-white bg-white text-2xl font-bold focus:outline-none shadow-2xl focus:border-emerald-300 transition-all"
            />
            <button
              type="button"
              onClick={startSpeechRecognition}
              className={`absolute right-4 top-4 w-16 h-16 rounded-full flex items-center justify-center transition-all ${isListening ? 'bg-red-500 animate-pulse' : 'bg-slate-100 hover:bg-slate-200'}`}
            >
              🎤
            </button>
          </form>
          
          <div className="grid grid-cols-2 gap-4">
            <button
              onClick={handleSubmit}
              disabled={loading || !query.trim()}
              className="h-24 text-2xl font-black rounded-[35px] border-b-[12px] bg-emerald-600 border-emerald-900 text-white shadow-xl active:border-b-4 active:translate-y-2 transition-all disabled:opacity-50"
            >
              HLEDAT
            </button>
            <button
              onClick={startCamera}
              disabled={!isOnline}
              className={`h-24 text-2xl font-black rounded-[35px] border-b-[12px] shadow-xl active:border-b-4 active:translate-y-2 transition-all flex items-center justify-center gap-3 ${isOnline ? 'bg-blue-600 border-blue-900 text-white' : 'bg-slate-400 border-slate-600 text-slate-200 opacity-60'}`}
            >
              📷 FOTO
            </button>
          </div>

          {error && <div className="mt-6 p-6 bg-red-100 border-4 border-red-500 rounded-3xl text-red-700 font-bold text-center animate-bounce-short">{error}</div>}
        </section>

        {loading && (
           <div className="mb-10 bg-white rounded-[50px] p-16 shadow-2xl flex flex-col items-center gap-6 text-center">
              <div className="w-16 h-16 border-[8px] border-emerald-100 border-t-emerald-600 rounded-full animate-spin"></div>
              <p className="text-2xl font-black uppercase text-slate-400 italic">Analyzuji odpad...</p>
           </div>
        )}

        {result && !loading && (
          <div className="mb-10 bg-white rounded-[50px] p-12 shadow-2xl border-[12px] border-emerald-100 relative overflow-hidden animate-in fade-in zoom-in duration-300">
            <div className={`absolute top-0 right-0 px-6 py-2 text-[10px] font-black uppercase tracking-widest ${result.source === 'local' ? 'bg-emerald-500 text-white' : 'bg-blue-500 text-white'}`}>
              {result.source === 'local' ? '📦 V databázi' : '✨ Obecná znalost'}
            </div>
            
            <div className="mb-8 text-center">
              <p className="text-lg font-bold text-slate-400 uppercase tracking-widest mb-4">
                {result.source === 'ai' ? 'Tuto položku nemám v databázi, ale obecně:' : 'Položka nalezena v databázi:'}
              </p>
              <h2 className="text-3xl font-black text-slate-900 mb-2 uppercase italic">
                **{result.name}** patří do:
              </h2>
            </div>

            <div className="mb-10"><CategoryBadge category={result.category} variant="hero" /></div>
            
            {result.note && (
              <div className="bg-slate-50 p-8 rounded-3xl border-4 border-slate-100 shadow-inner">
                 <p className="text-2xl font-bold text-slate-700 italic text-center">"{result.note}"</p>
              </div>
            )}
            
            <button onClick={() => setResult(null)} className="w-full mt-8 h-20 bg-slate-800 text-white rounded-3xl font-black text-xl active:scale-95 transition-all shadow-lg">ROZUMÍM</button>
          </div>
        )}

        {history.length > 0 && !result && !loading && (
          <section className="space-y-6">
            <h3 className="text-2xl font-black uppercase italic text-slate-500 px-6">Historie třídění</h3>
            <div className="space-y-4">
              {history.map((item, i) => (
                <button 
                  key={i} 
                  onClick={() => {
                    const res = { ...item.result, source: (item.result as any).source };
                    setResult(res);
                    announceResult(res.category);
                  }}
                  className="w-full bg-white p-6 rounded-3xl border-4 border-white shadow-lg flex justify-between items-center active:scale-95 transition-all text-left"
                >
                  <div className="flex flex-col">
                    <span className="text-xl font-bold text-slate-800 truncate pr-4">{item.query}</span>
                    <span className="text-xs text-slate-400 font-bold uppercase">{new Date(item.timestamp).toLocaleTimeString('cs-CZ')}</span>
                  </div>
                  <CategoryBadge category={item.result.category} variant="minimal" />
                </button>
              ))}
            </div>
          </section>
        )}

        {isCameraOpen && (
          <div className="fixed inset-0 z-50 bg-black flex flex-col">
            <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover" />
            <div className="absolute inset-0 border-[20px] border-white/20 pointer-events-none"></div>
            <div className="absolute bottom-12 left-0 right-0 flex justify-center gap-8 px-10">
              <button onClick={stopCamera} className="bg-white/20 text-white px-8 py-6 rounded-3xl font-bold text-xl backdrop-blur-md">ZPĚT</button>
              <button onClick={capturePhoto} className="w-24 h-24 bg-white rounded-full border-[10px] border-emerald-500 shadow-2xl active:scale-90 transition-all"></button>
            </div>
          </div>
        )}
      </main>

      <canvas ref={canvasRef} className="hidden" />
    </div>
  );
};

export default App;
