
import { WasteCategory } from './types';

export const WASTE_DATABASE = [
  // PLASTY (Žlutá)
  { name: 'PET láhev', category: WasteCategory.PLAST, note: 'Sešlápnout! Víčko může zůstat na láhvi.' },
  { name: 'kelímek od jogurtu', category: WasteCategory.PLAST, note: 'Stačí lehce vyškrábat, nemusí se drhnout.' },
  { name: 'sáček od bonbonů', category: WasteCategory.PLAST, note: 'Pokud není uvnitř pokovený (stříbrný).' },
  { name: 'fólie a bublinková fólie', category: WasteCategory.PLAST, note: 'Čistý plastový obal.' },
  { name: 'polystyren', category: WasteCategory.PLAST, note: 'Pouze čistý bílý, ne stavební se zbytky malty.' },
  { name: 'krabice od mléka', category: WasteCategory.PLAST, note: 'Nápojový karton (TetraPak). V ČR většinou do žlutého (oranžová nálepka).' },
  { name: 'obal od šamponu', category: WasteCategory.PLAST, note: 'Prázdný a vypláchnutý.' },
  { name: 'plastové víčko', category: WasteCategory.PLAST, note: 'Drobné plastové uzávěry.' },
  { name: 'balicí fólie', category: WasteCategory.PLAST, note: 'Čistý streč nebo smršťovací fólie.' },
  { name: 'kelímek od pomazánky', category: WasteCategory.PLAST, note: 'Zbavený zbytků jídla.' },
  
  // PAPÍR (Modrá)
  { name: 'kartonová krabice', category: WasteCategory.PAPIR, note: 'Důkladně rozložit nebo roztrhat, ať nezabírá místo.' },
  { name: 'noviny a časopisy', category: WasteCategory.PAPIR, note: 'Bez laminovaných obálek.' },
  { name: 'kancelářský papír', category: WasteCategory.PAPIR, note: 'Spony a svorky nevadí, při zpracování se odstraní.' },
  { name: 'obálka s okénkem', category: WasteCategory.PAPIR, note: 'Plastové okénko nevadí, oddělí se při recyklaci.' },
  { name: 'proložka od vajec', category: WasteCategory.PAPIR, note: 'Nově lze recyklovat v modrém kontejneru nebo dát do kompostu.' },
  { name: 'rulička od toaletního papíru', category: WasteCategory.PAPIR, note: 'Lze recyklovat v modrém kontejneru.' },
  { name: 'papírový sáček', category: WasteCategory.PAPIR, note: 'Čistý, nezamaštěný.' },
  { name: 'katalog', category: WasteCategory.PAPIR, note: 'Papírová vazba nevadí.' },

  // SKLO (Zelená/Bílá)
  { name: 'láhev od vína', category: WasteCategory.SKLO, note: 'Vhodit do zeleného (barevné) nebo bílého (čiré) kontejneru.' },
  { name: 'zavařovací sklenice', category: WasteCategory.SKLO, note: 'Bez kovového víčka (víčko patří do kovů).' },
  { name: 'parfém', category: WasteCategory.SKLO, note: 'Skleněný flakon bez plastového rozprašovače.' },
  { name: 'tabulové sklo', category: WasteCategory.SKLO, note: 'V malém množství do zeleného kontejneru.' },
  { name: 'skleněná váza', category: WasteCategory.SKLO, note: 'Bez kovových ozdob.' },

  // BIOODPAD (Hnědá)
  { name: 'slupky od brambor', category: WasteCategory.BIO, note: 'Bez igelitového sáčku! Použijte papírový nebo žádný.' },
  { name: 'čajový sáček', category: WasteCategory.BIO, note: 'Pouze pokud je papírový bez plastových sítěk.' },
  { name: 'kávová sedlina', category: WasteCategory.BIO, note: 'Lze vyhodit i s papírovým filtrem.' },
  { name: 'zbytky ovoce a zeleniny', category: WasteCategory.BIO, note: 'Bez samolepek z ovoce.' },
  { name: 'listí a tráva', category: WasteCategory.BIO, note: 'Zahradní odpad.' },
  { name: 'ostříhané nehty', category: WasteCategory.BIO, note: 'Přírodní původ.' },
  { name: 'květiny', category: WasteCategory.BIO, note: 'Bez květináčů a drátků.' },

  // KOVY (Šedá)
  { name: 'plechovka od piva', category: WasteCategory.KOVY, note: 'Sešlápnout! Hliníkový obal.' },
  { name: 'konzerva od jídla', category: WasteCategory.KOVY, note: 'Vymytá od zbytků jídla.' },
  { name: 'alobal', category: WasteCategory.KOVY, note: 'Pouze čistý, nezamaštěný.' },
  { name: 'kovové víčko', category: WasteCategory.KOVY, note: 'Od zavařenin nebo piva.' },
  { name: 'hliníkové víčko', category: WasteCategory.KOVY, note: 'Např. od jogurtu, pokud se vyhazuje samostatně.' },

  // SMĚSNÝ ODPAD (Černá)
  { name: 'papírový kapesník', category: WasteCategory.SMESNY, note: 'Z hygienických důvodů nepatří do papíru.' },
  { name: 'účtenka z obchodu', category: WasteCategory.SMESNY, note: 'Termopapír obsahuje BPA, nepatří do recyklace papíru.' },
  { name: 'porcelánový hrnek', category: WasteCategory.SMESNY, note: 'Keramika a porcelán do skla nepatří.' },
  { name: 'houbička na nádobí', category: WasteCategory.SMESNY, note: 'Kombinace různých materiálů.' },
  { name: 'dětská plena', category: WasteCategory.SMESNY, note: 'Hygienický odpad.' },
  { name: 'mastný papír', category: WasteCategory.SMESNY, note: 'Znečištěný papír (např. od pizzy) nelze recyklovat.' },
  { name: 'vychladlý popel', category: WasteCategory.SMESNY, note: 'Pouze pokud není ze dřeva (dřevěný může do kompostu).' },
  { name: 'kartáček na zuby', category: WasteCategory.SMESNY, note: 'Kombinace plastu a štětin.' },

  // SBĚRNÝ DVŮR / OSTATNÍ
  { name: 'zrcadlo', category: WasteCategory.SBERNY_DVUR, note: 'Obsahuje kovovou odrazovou vrstvu, nepatří do skla.' },
  { name: 'baterie', category: WasteCategory.SBERNY_DVUR, note: 'Odevzdejte do sběrných boxů v obchodech.' },
  { name: 'staré léky', category: WasteCategory.LEKARNA, note: 'VŽDY odevzdejte v lékárně, nikdy nevyhazujte do koše.' },
  { name: 'pneumatika', category: WasteCategory.SBERNY_DVUR, note: 'Místo zpětného odběru nebo sběrný dvůr.' },
  { name: 'barva nebo lak', category: WasteCategory.SBERNY_DVUR, note: 'Nebezpečný odpad.' },
  { name: 'lednice nebo pračka', category: WasteCategory.SBERNY_DVUR, note: 'Vysloužilé elektrospotřebiče.' },
  { name: 'staré tričko', category: WasteCategory.TEXTIL, note: 'Pokud je v dobrém stavu, darujte ho charitě.' },
  { name: 'olej na smažení', category: WasteCategory.OLEJE, note: 'Přelít do PET láhve a vhodit do speciálního černého kontejneru.' },
  { name: 'žárovka', category: WasteCategory.SBERNY_DVUR, note: 'Klasické i úsporné žárovky.' },
  { name: 'mobilní telefon', category: WasteCategory.SBERNY_DVUR, note: 'Elektroodpad.' }
];

export const SYSTEM_INSTRUCTION = `
Jsi "Recyklační Asistent", specializovaný AI agent pro pomoc s tříděním domácího odpadu v ČR.

TVÉ ZNALOSTI:
- Primárně vycházej z této databáze: ${JSON.stringify(WASTE_DATABASE)}.
- Pokud položku v databázi najdeš (přesná nebo velmi blízká shoda), nastav "isFromDatabase" na true.
- Pokud položku v databázi NENAJDĚŠ, nastav "isFromDatabase" na false a urči kategorii podle svých obecných znalostí.

PRAVIDLA PRO ODPOVĚDI:
- Buď stručný a věcný.
- "category" musí být přesně jeden z klíčů WasteCategory.
- Do "note" přidej doplňující instrukce (např. vymýt, sešlápnout).

ODPOVÍDEJ VŽDY V TOMTO JSON FORMÁTU:
{
  "name": "Název odpadu",
  "category": "String z WasteCategory",
  "note": "Poznámka",
  "isFromDatabase": true/false
}
`;
