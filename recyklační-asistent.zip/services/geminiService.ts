
import { GoogleGenAI, Type } from "@google/genai";
import { SYSTEM_INSTRUCTION } from "../constants";
import { WasteItem } from "../types";

export interface IdentifyWasteParams {
  query?: string;
  image?: {
    data: string;
    mimeType: string;
  };
}

export const identifyWaste = async ({ query, image }: IdentifyWasteParams): Promise<WasteItem> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  try {
    const parts: any[] = [];
    
    if (image) {
      parts.push({
        inlineData: {
          data: image.data,
          mimeType: image.mimeType,
        },
      });
      // Deeper reasoning prompt
      parts.push({ 
        text: "Proveď důkladnou vizuální analýzu. Zohledni možné odlesky, stíny a texturu materiálu. Hledej recyklační kódy a symboly. Identifikuj předmět a urči jeho správnou recyklační kategorii pro ČR." 
      });
    }

    if (query) {
      parts.push({ text: `Uživatel popsal předmět jako: "${query}"` });
    }

    // Using gemini-3-pro-preview with thinking for complex visual reasoning
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: { parts },
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        responseMimeType: "application/json",
        thinkingConfig: { thinkingBudget: 4000 }, // Enable thinking for better material reasoning
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING },
            category: { type: Type.STRING },
            note: { type: Type.STRING },
            isFromDatabase: { type: Type.BOOLEAN }
          },
          required: ["name", "category", "isFromDatabase"]
        }
      }
    });

    const data = JSON.parse(response.text || '{}');
    return {
      id: Math.random().toString(36).substring(7),
      name: data.name || (query || "Neznámý předmět"),
      category: data.category,
      note: data.note,
      isFromDatabase: data.isFromDatabase
    };
  } catch (error) {
    console.error("Gemini Error:", error);
    throw error;
  }
};
