
/**
 * Calculates the Levenshtein distance between two strings.
 * Lower distance means higher similarity.
 */
export function getLevenshteinDistance(s: string, t: string): number {
  if (!s.length) return t.length;
  if (!t.length) return s.length;
  const arr = [];
  for (let i = 0; i <= t.length; i++) {
    arr[i] = [i];
    for (let j = 1; j <= s.length; j++) {
      arr[i][j] =
        i === 0
          ? j
          : Math.min(
              arr[i - 1][j] + 1,
              arr[i][j - 1] + 1,
              arr[i - 1][j - 1] + (s[j - 1] === t[i - 1] ? 0 : 1)
            );
    }
  }
  return arr[t.length][s.length];
}

/**
 * Normalizes a string for comparison (lowercase, trimmed, remove accents/diacritics for better matching).
 */
const normalize = (str: string) => 
  str.toLowerCase()
     .trim()
     .normalize("NFD")
     .replace(/[\u0300-\u036f]/g, ""); // Odstranění diakritiky pro robustnější hledání

/**
 * Searches for a match in the local database using multiple strategies:
 * 1. Exact match (highest priority)
 * 2. Starts with (high priority)
 * 3. Contains (medium priority)
 * 4. Fuzzy match (Levenshtein distance, lowest priority)
 */
export function findLocalMatch<T extends { name: string }>(
  query: string,
  database: T[],
  fuzzyThreshold: number = 2
): T | null {
  const q = normalize(query);
  if (!q || q.length < 2) return null; // Ignorujeme příliš krátké dotazy

  let bestMatch: T | null = null;
  let bestScore = Infinity;

  for (const item of database) {
    const itemName = normalize(item.name);
    let currentScore = Infinity;

    // 1. Přesná shoda
    if (itemName === q) {
      currentScore = 0;
    } 
    // 2. Začíná na... (velmi silný signál u názvů odpadu)
    else if (itemName.startsWith(q)) {
      // Skóre založené na tom, kolik zbývá do konce slova (čím kratší zbytek, tím lepší)
      currentScore = 0.1 + (itemName.length - q.length) / 100;
    }
    // 3. Obsahuje podřetězec
    else if (itemName.includes(q)) {
      currentScore = 0.5 + (itemName.length - q.length) / 100;
    }
    // 4. Dotaz obsahuje název položky (např. "rozbitá pet láhev" obsahuje "pet láhev")
    else if (q.includes(itemName)) {
      currentScore = 0.6 + (q.length - itemName.length) / 100;
    }
    // 5. Fuzzy shoda (Levenshtein)
    else {
      const distance = getLevenshteinDistance(q, itemName);
      if (distance <= fuzzyThreshold) {
        // Penalizace fuzzy shody, aby nevyhrála nad jasným podřetězcem
        currentScore = 1.0 + distance;
      }
    }

    if (currentScore < bestScore) {
      bestScore = currentScore;
      bestMatch = item;
    }
  }

  // Pokud je nejlepší skóre příliš vysoké, považujeme to za "nenalezeno"
  return bestScore < 3 ? bestMatch : null;
}
